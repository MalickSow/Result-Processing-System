/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rps_interfaces;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author Myriam
 */
public class ViewGradeRegisterController {
    

   @FXML
    private JFXTextField SID;

    @FXML
    private JFXComboBox<String> Semester;
    @FXML
    private JFXComboBox<String> courselist;

    @FXML
    private JFXTextArea GPA;

    @FXML
    private JFXTextArea CGPA;

   
    @FXML
    private TableView<CourseGrade> CourseGradeTable;
    @FXML
    private TableColumn<CourseGrade, String> student_colcourse;
    @FXML
    private TableColumn<CourseGrade, String> student_colgrade;
    
    
     
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
       
    }  
    
     public void setComboboxValue(){
        Semester.getItems().add("1st");
        Semester.getItems().add("2nd");
        Semester.getItems().add("3rd");
        Semester.getItems().add("4th");
        Semester.getItems().add("5th");
        Semester.getItems().add("6th");
        Semester.getItems().add("7th");
        Semester.getItems().add("8th");
    }

    @FXML
    private void student_done(MouseEvent event) {
        String s= Semester.getSelectionModel().getSelectedItem();
        char[] si= s.toCharArray();
        Integer i= si[0] - 48;
        try{
            Class.forName("oracle.jdbc.OracleDriver");
             String host ="jdbc:oracle:thin:@localhost:1521:XE";
            String username ="project";
            String userpass ="project";
            Connection con =DriverManager.getConnection(host,username,userpass);
            String Query="Select GPA from GpaSemester where Student_ID=? and Semester=?";
            PreparedStatement pst=con.prepareStatement(Query);
            pst.setString(1, SID.getText());
            pst.setInt(2,i);
            ResultSet rs=pst.executeQuery();
            
            while(rs.next()){
                Integer strsize=rs.getString("GPA").length();
                if(strsize>4)
                GPA.setText(rs.getString("GPA").substring(0, 4));
                else{
                    GPA.setText(rs.getString("GPA"));
                }
                                              
            
        }
            rs.close();
        }
        catch(ClassNotFoundException | SQLException e){
                System.out.println(e);
                }
       try{
            Class.forName("oracle.jdbc.OracleDriver");
             String host ="jdbc:oracle:thin:@localhost:1521:XE";
            String username ="project";
            String userpass ="project";
            Connection con =DriverManager.getConnection(host,username,userpass);
            String Query="Select CGPA from TCGPA where Student_ID=?";
            PreparedStatement pst=con.prepareStatement(Query);
            pst.setString(1, SID.getText());
           
            ResultSet rs=pst.executeQuery();
            
            while(rs.next()){
                Double value =rs.getDouble("CGPA");
                CGPA.setText(String.format("%.2f",value));
                                              
            
        }
            rs.close();
        }
        catch(ClassNotFoundException | SQLException e){
                System.out.println(e);
                }
       
       setTableValue();
    }
    
    private void setTableValue(){
        ObservableList<CourseGrade> list =FXCollections.observableArrayList();
        String s= Semester.getSelectionModel().getSelectedItem();
        char[] si= s.toCharArray();
        Integer i= si[0] - 48;
        try{
             Class.forName("oracle.jdbc.OracleDriver");
             String host ="jdbc:oracle:thin:@localhost:1521:XE";
            String username ="project";
            String userpass ="project";
            Connection con =DriverManager.getConnection(host,username,userpass);;
            String Query="Select CourseID,gradecharacter from Marks where StudentID=? and Semester=?";
            PreparedStatement pst=con.prepareStatement(Query);
            pst.setString(1, SID.getText());
            pst.setInt(2,i);
            ResultSet rs=pst.executeQuery();
            
            while(rs.next()){
                list.add(new CourseGrade(rs.getString("CourseID"),rs.getString("Gradecharacter")));
                                               
            
        }
            rs.close();
        }
        catch(ClassNotFoundException | SQLException e){
                System.out.println(e);
                }
        
        student_colcourse.setCellValueFactory(new PropertyValueFactory<>("Course"));
        student_colgrade.setCellValueFactory(new PropertyValueFactory<>("Grade"));
        CourseGradeTable.setItems(list);
        
         // SAVE VALUES INTO TABLEPDF FOR PDF
          String[] pdftableval=new String[50];
           Integer j=0;
           PdfVal obj[]=new PdfVal[10];
           int count=0;int row = 0;
         
         try{
             System.out.println("2222VAlll");
             Class.forName("oracle.jdbc.OracleDriver");
             String host ="jdbc:oracle:thin:@localhost:1521:XE";
            String username ="project";
            String userpass ="project";
            Connection con =DriverManager.getConnection(host,username,userpass);
            String Query="Select CourseID,gradecharacter,COURSE.NAME,course.credit from Marks,COURSE where COURSE.ID=Marks.courseid AND StudentID=? and Semester=?";
            PreparedStatement pst=con.prepareStatement(Query);
            
            //pst.setString(1,"MARKS.CourseID");
            pst.setString(1, SID.getText());
            pst.setInt(2,i);
            ResultSet rs=pst.executeQuery();
            String val;
            
            
          
            
            while(rs.next()){
               pdftableval[j]=rs.getString(1);
               j++;
               pdftableval[j]=rs.getString(2);
               j++;
               pdftableval[j]=rs.getString(3);
               j++;
               pdftableval[j]=rs.getString(4);
               j++;
               row=rs.getRow();
               
           
             

                
                //String Query2="insert into pdftable values(?,?,?,?)";
               
               /* pst2.setString(1,rs.getString(1));
                pst2.setString(2,rs.getString(2));
                pst2.setString(3,rs.getString(3));
                pst2.setString(4,rs.getString(4));
                pst2.executeUpdate(Query2);*/
                                               
            
        }
            rs.close();
        }
        catch(ClassNotFoundException | SQLException e){
                System.out.println(e);
                }
        
      /*for(i=0;i<j;i++)
      {
          System.out.println(pdftableval[i]);
      }*/
      Integer k=0;
      for(i=0;i<row;i++){
      try{
             Class.forName("oracle.jdbc.OracleDriver");
             String host ="jdbc:oracle:thin:@localhost:1521:XE";
            String username ="project";
            String userpass ="project";
            Connection con =DriverManager.getConnection(host,username,userpass);;
            String Query="insert into pdftable(courseid,grade,coursetittle,credit) values(?,?,?,?)";
            PreparedStatement pst=con.prepareStatement(Query);
            pst.setString(1,pdftableval[k]);
            k++;
            pst.setString(2,pdftableval[k]);
            k++;
            pst.setString(3,pdftableval[k]);
            k++;
            pst.setString(4,pdftableval[k]);
            k++;
            
            pst.executeUpdate();
            
          
        }
        catch(ClassNotFoundException | SQLException e){
                System.out.println(e);
                }
    }
 }

   @FXML
    private void SavePDFStudents(){
         Connection con = null;
         System.out.println("PDFFFF");
        String StudentName=null;
        String StudentID=SID.getText();
        String StudentCGPA=CGPA.getText();
        String StudentGPA=GPA.getText();
        String StudentSemester=Semester.getSelectionModel().getSelectedItem();
        String Studentprog=null;
        String Studentyear=null;
        
       

        try{
             Class.forName("oracle.jdbc.OracleDriver");
             String host ="jdbc:oracle:thin:@localhost:1521:XE";
            String username ="project";
            String userpass ="project";
           con =DriverManager.getConnection(host,username,userpass);
           String Query="select * from student where id=?";
           PreparedStatement pst=con.prepareStatement(Query);
           pst.setString(1, SID.getText());
           ResultSet rs=pst.executeQuery();
            
            while(rs.next()){
               
                Studentprog=rs.getString("programme");
                Studentyear=rs.getString("Year");
                
                                               
        }
        rs.close();
                       
        }
        catch(ClassNotFoundException | SQLException e){
                System.out.println(e);
                }
        
       
        try{
             Class.forName("oracle.jdbc.OracleDriver");
             String host ="jdbc:oracle:thin:@localhost:1521:XE";
            String username ="project";
            String userpass ="project";
           con =DriverManager.getConnection(host,username,userpass);
           String Query="select name from student where id=?";
           PreparedStatement pst=con.prepareStatement(Query);
           pst.setString(1, SID.getText());
           ResultSet rs=pst.executeQuery();
            
            while(rs.next()){
               
                StudentName=rs.getString("Name");
                                               
        }
        rs.close();
                       
        }
        catch(ClassNotFoundException | SQLException e){
                System.out.println(e);
                }
        
        
        
        try{
            InputStream in=new FileInputStream(new File("C:\\Users\\Myriam\\Documents\\NetBeansProjects\\myproject\\src\\myproject\\CourseGradeReport_1.jrxml"));
            
            JasperDesign jd=JRXmlLoader.load(in);
            String sql="select * from pdftable";
            JRDesignQuery newQuery= new JRDesignQuery();
            newQuery.setText(sql);
            jd.setQuery(newQuery);
            JasperReport jr=JasperCompileManager.compileReport(jd);
            HashMap para= new HashMap();
            para.put("Name",StudentName);
            para.put("ID",StudentID);
            para.put("GPA",StudentGPA);
            para.put("CGPA",StudentCGPA);
            para.put("Semester",StudentSemester);
            switch(Studentprog){
                case "1" : Studentprog="Bsc";
                break;
                case "2" : Studentprog="Hde";
                break;
                default :
                    
            }
            para.put("Programme",Studentprog);
            para.put("Year",Studentyear);
            

            
            
            
            JasperPrint j=JasperFillManager.fillReport(jr,para,con);
            JasperViewer.viewReport(j,false);
            OutputStream os= new FileOutputStream(new File("D:\\iReport\\thereport.pdf"));
            JasperExportManager.exportReportToPdfStream(j,os);
            
        }
        catch(Exception e){
            System.out.println(e);
        }
        
        //delete values in pdftable
        try{
             Class.forName("oracle.jdbc.OracleDriver");
             String host ="jdbc:oracle:thin:@localhost:1521:XE";
            String username ="project";
            String userpass ="project";
           con =DriverManager.getConnection(host,username,userpass);
           String Query="delete pdftable";
           PreparedStatement pst=con.prepareStatement(Query);
           
           pst.executeUpdate();
        
        }
        catch(ClassNotFoundException | SQLException e){
                System.out.println(e);
                }
    
}

    
}
