/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rps_interfaces;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.Duration;
import java.util.ResourceBundle;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;


/**
 * FXML Controller class
 *
 * @author Myriam
 */
public class RegStdController implements Initializable {
    @FXML
    JFXComboBox<String> combobox;
    @FXML
    JFXComboBox<String> comboboxprogramme;
    @FXML
    private JFXTextField ID;
    @FXML
    private JFXTextField Name;
    @FXML
    private JFXTextField Phone;
    @FXML
    private JFXTextField Address;
    @FXML
    private JFXTextField Guardian_ID;
    @FXML
    private JFXTextField Country;
    @FXML
    private JFXTextField Section;
    @FXML
    private JFXTextField Year;
    @FXML
    private ImageView savedimage;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        combobox.getItems().add("CSE");
        combobox.getItems().add("EEE");
        combobox.getItems().add("MCE");
        comboboxprogramme.getItems().add("BSc");
        comboboxprogramme.getItems().add("HDE");
       
    }    

    @FXML
    private void SaveAction(MouseEvent event) throws URISyntaxException {
        
        try{
            Class.forName("oracle.jdbc.OracleDriver");
             String host ="jdbc:oracle:thin:@localhost:1521:XE";
            String username ="project";
            String userpass ="project";
            Connection con =DriverManager.getConnection(host,username,userpass);
           CallableStatement callableStmt = con.prepareCall("{call PROC_STUDENT_INSERT_IN(?,?,?,?,?,?,?,?,?)}");
           
           //IN parameter -
           //   1) set methods are used for setting IN parameter values of Stored procedure
           String prog=null;
           callableStmt.setString(1, Name.getText());
           callableStmt.setString(2, Phone.getText());
           callableStmt.setString(3, Address.getText());
           callableStmt.setString(4, Guardian_ID.getText());
           callableStmt.setString(5, Country.getText());
           callableStmt.setString(6, combobox.getSelectionModel().getSelectedItem().toLowerCase());
           callableStmt.setString(7, Year.getText());
           callableStmt.setString(8, Section.getText());
           switch(comboboxprogramme.getSelectionModel().getSelectedItem()){
               case "BSc": prog="1";
               break;
               case "HDE": prog="2";
               break;
               
               default:
           }
           callableStmt.setString(9, prog);
           
           
          
 
           // execute database Stored procedure
           callableStmt.executeUpdate();

            
            
        }
        catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
        
        
        ResetAllAction(event);
    }

    @FXML
    private void ResetAllAction(MouseEvent event) {
        Name.setText("");
        Phone.setText("");
        Address.setText("");
        Guardian_ID.setText("");
        Country.setText("");
        Section.setText("");
        Year.setText("");
        combobox.getSelectionModel().clearSelection();
        comboboxprogramme.getSelectionModel().clearSelection();

        
        
    }
    
}
