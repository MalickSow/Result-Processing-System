/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rps_interfaces;

/**
 *
 * @author Myriam
 */
public class StudentCgpa {
    String ID;
    String CGPA;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getCGPA() {
        return CGPA;
    }

    public void setCGPA(String CGPA) {
        this.CGPA = CGPA;
    }

    public StudentCgpa(String ID, String CGPA) {
        this.ID = ID;
        this.CGPA = CGPA;
    }
    
}
