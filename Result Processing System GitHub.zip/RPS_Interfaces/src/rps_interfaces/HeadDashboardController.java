/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rps_interfaces;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Myriam
 */
public class HeadDashboardController implements Initializable {
    String Department;
    @FXML 
    private BorderPane bp;
    @FXML
    private ImageView imageview;
    @FXML
    private ImageView imageview1;
    @FXML
    private ImageView imageview2;
    @FXML
    private ImageView imageview3;
    @FXML
    private ImageView imageview4;
    
    @FXML
    private AnchorPane ap;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }   
    public void getHeadDepartment(String id){
        System.out.println("GetId "+ id);
        Department=id;
    }
     private void loadPage(String Page){
        Parent root=null;
        
        try {
            root=FXMLLoader.load(getClass().getResource(Page +".fxml"));
        } catch (IOException ex) {
            Logger.getLogger(TeacherDashboardController.class.getName()).log(Level.SEVERE, null, ex);
        }
        bp.setCenter(root);
       
        
    }

    @FXML
    private void RegisterCourseAction(MouseEvent event) {
        loadPage("RegCourse");
        
    }

    @FXML
    private void RegisterTeacherAction(MouseEvent event) {
        loadPage("RegTeacher");
    }

    @FXML
    private void GradeAction(MouseEvent event) throws IOException {
       //loadPage("ViewGradeHead_Final2");
       
       FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("ViewGradeHead_Final2.fxml"));
                
                Parent root=loader.load();
                //Parent root= FXMLLoader.load(getClass().getResource("TeacherDashboard.fxml"));
                
                //Scene TeacherScene = new Scene(root);
                
                ViewGradeHead_Final2Controller controller= loader.getController();
               
                bp.setCenter(root);
                
                controller.getHeadDepartment(Department);
                
    }

    @FXML
    private void UpdateCourseAction(MouseEvent event) {
        loadPage("UpdateCourse");
    }

    @FXML
    private void RegStdtCourseAction(MouseEvent event) {
        loadPage("RegStdtoCourse");
    }
    @FXML
    private void LogoutAction(MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("Login.fxml"));
                
                Parent root=loader.load();
                //Parent root= FXMLLoader.load(getClass().getResource("TeacherDashboard.fxml"));
                
                Scene TeacherScene = new Scene(root);
                
                LoginController controller= loader.getController();
               
                //controller.getTeacherID(rs_Teacher.getString("Id"));
                // Put Scene on same Stage
                Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
                
                // put scene on new stage : Stage window = new Stage();
                
                
                window.setScene(TeacherScene);
                window.show();
    }
    
}
