/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rps_interfaces;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import com.jfoenix.controls.JFXTextField;
import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Myriam
 */
public class UpdateCourseController implements Initializable {
    @FXML
    private JFXTextField Courseidold;

    @FXML
    private JFXTextField courseidnew;

    @FXML
    private JFXTextField name;

    @FXML
    private JFXTextField credit;

    @FXML
    private JFXTextField courseteacherid;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
        @FXML
    public void Saveaction(MouseEvent event) {

    }
    
}
